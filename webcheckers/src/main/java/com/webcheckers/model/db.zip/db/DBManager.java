package com.webcheckers.model.db;

import java.util.List;
import java.util.Map;
import org.hibernate.Session;

public class DBManager implements IDataManager{
    Session session;
    public DBManager()
    {
        HibernateUtil hibutil = new HibernateUtil();
        this.session= hibutil.getSessionFactory().openSession();    
    }
    @Override
    public void save(Object obj) {
        session.beginTransaction();
        session.save(obj);
        session.getTransaction().commit();
    }

    @Override
    public void delete(long id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Object obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object findById(long id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Object> find(Map<String, String> fieldValueMap) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
