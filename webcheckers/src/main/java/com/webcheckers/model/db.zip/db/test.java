/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.webcheckers.model.db;

import com.webcheckers.model.HumanPlayer;
import com.webcheckers.model.Player;
import java.io.File;

/**
 *
 * @author bm3302
 */
public class test {
    public static void main(String[] args) {

//        String temp = System.getProperty("user.dir")+("/src/main/java/com/webcheckers/model/db/hibernate.cfg.xml");
//        System.out.println(temp);
//        File file = new File(temp);
//        boolean exists = file.exists();
//        System.out.println(exists);
        DBManager db = new  DBManager();
        Player p = new HumanPlayer();
        db.save(p);
        
    }
}

